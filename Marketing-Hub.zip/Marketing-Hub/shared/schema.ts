import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table (for reference)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Campaign Goals enum
export const campaignGoals = ["onboarding", "product_adoption", "new_product_awareness"] as const;
export type CampaignGoal = typeof campaignGoals[number];

// Product types enum
export const products = ["product_a", "product_b", "product_c"] as const;
export type Product = typeof products[number];

// Tactics enum
export const tactics = ["onboarding_checklist", "churn_prevention", "promotion"] as const;
export type Tactic = typeof tactics[number];

// Channels enum
export const channels = ["email", "sms", "mobile_push", "paid"] as const;
export type Channel = typeof channels[number];

// Campaign status enum
export const campaignStatuses = ["draft", "active", "paused", "completed"] as const;
export type CampaignStatus = typeof campaignStatuses[number];

// Campaign interface for in-memory storage
export interface Campaign {
  id: string;
  name: string;
  description: string;
  goal: CampaignGoal;
  product: Product;
  tactic: Tactic;
  channels: Channel[];
  status: CampaignStatus;
  targetAudienceSize: number;
  createdAt: string;
  updatedAt: string;
}

export interface InsertCampaign {
  name: string;
  description: string;
  goal: CampaignGoal;
  product: Product;
  tactic: Tactic;
  channels: Channel[];
}

export const insertCampaignSchema = z.object({
  name: z.string().min(1, "Campaign name is required"),
  description: z.string().min(1, "Description is required"),
  goal: z.enum(campaignGoals),
  product: z.enum(products),
  tactic: z.enum(tactics),
  channels: z.array(z.enum(channels)).min(1, "Select at least one channel"),
});

// CDP Customer Data (simulated from internal CDP)
export interface CDPCustomer {
  id: string;
  accountName: string;
  industry: string;
  companySize: "small" | "medium" | "large" | "enterprise";
  productAdoption: {
    productA: number; // 0-100 adoption score
    productB: number;
    productC: number;
  };
  lastActivity: string;
  onboardingComplete: boolean;
  churnRisk: "low" | "medium" | "high";
  headroom: number; // potential growth 0-100
  crmStage: "prospect" | "trial" | "active" | "at_risk" | "churned";
  marketingOptIn: {
    email: boolean;
    sms: boolean;
    mobile_push: boolean;
    paid: boolean;
  };
}

// Audience Segment
export interface AudienceSegment {
  totalSize: number;
  matchedCustomers: CDPCustomer[];
  segmentCriteria: {
    goal: CampaignGoal;
    product: Product;
    tactic: Tactic;
    channels: Channel[];
  };
  channelReach: {
    email: number;
    sms: number;
    mobile_push: number;
    paid: number;
  };
}

// Creative Assets
export interface CreativeAsset {
  id: string;
  name: string;
  type: "image" | "video" | "copy" | "template";
  category: CampaignGoal;
  product: Product;
  tactic: Tactic;
  channel: Channel;
  previewUrl?: string;
  content: string;
}

// Narrative/Messaging
export interface Narrative {
  id: string;
  title: string;
  headline: string;
  subheadline: string;
  bodyContent: string;
  callToAction: string;
  goal: CampaignGoal;
  product: Product;
  tactic: Tactic;
  tone: "professional" | "friendly" | "urgent" | "educational";
}

// Creative Recommendation
export interface CreativeRecommendation {
  narratives: Narrative[];
  assets: CreativeAsset[];
  suggestedSubjectLines: string[];
  recommendedTiming: string;
}

// Display helpers
export const goalLabels: Record<CampaignGoal, string> = {
  onboarding: "Onboarding",
  product_adoption: "Product Adoption",
  new_product_awareness: "New Product Awareness",
};

export const productLabels: Record<Product, string> = {
  product_a: "Product A",
  product_b: "Product B",
  product_c: "Product C",
};

export const tacticLabels: Record<Tactic, string> = {
  onboarding_checklist: "Onboarding Checklist",
  churn_prevention: "Churn Prevention",
  promotion: "Promotion",
};

export const channelLabels: Record<Channel, string> = {
  email: "Email",
  sms: "SMS",
  mobile_push: "Mobile Push",
  paid: "Paid Ads",
};

export const statusLabels: Record<CampaignStatus, string> = {
  draft: "Draft",
  active: "Active",
  paused: "Paused",
  completed: "Completed",
};
