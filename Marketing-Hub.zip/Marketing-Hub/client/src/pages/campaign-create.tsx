import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ArrowLeft, Loader2, Sparkles, Target, Package, Zap, Radio, Mail, MessageSquare, Smartphone, Megaphone } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  insertCampaignSchema,
  campaignGoals,
  products,
  tactics,
  channels,
  goalLabels,
  productLabels,
  tacticLabels,
  channelLabels,
  type InsertCampaign,
  type Channel,
} from "@shared/schema";

const goalIcons = {
  onboarding: Target,
  product_adoption: Package,
  new_product_awareness: Sparkles,
};

const channelIcons = {
  email: Mail,
  sms: MessageSquare,
  mobile_push: Smartphone,
  paid: Megaphone,
};

export default function CampaignCreate() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedChannels, setSelectedChannels] = useState<Channel[]>([]);

  const form = useForm<InsertCampaign>({
    resolver: zodResolver(insertCampaignSchema),
    defaultValues: {
      name: "",
      description: "",
      goal: "onboarding",
      product: "product_a",
      tactic: "onboarding_checklist",
      channels: [],
    },
  });

  const createCampaign = useMutation({
    mutationFn: async (data: InsertCampaign) => {
      const response = await apiRequest("POST", "/api/campaigns", data);
      return response.json();
    },
    onSuccess: (campaign) => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({
        title: "Campaign created",
        description: "Your campaign has been created successfully.",
      });
      navigate(`/campaigns/${campaign.id}`);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create campaign. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleChannelToggle = (channel: Channel, checked: boolean) => {
    const newChannels = checked
      ? [...selectedChannels, channel]
      : selectedChannels.filter((c) => c !== channel);
    setSelectedChannels(newChannels);
    form.setValue("channels", newChannels, { shouldValidate: true });
  };

  const onSubmit = (data: InsertCampaign) => {
    createCampaign.mutate(data);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-6">
        <Link href="/">
          <Button variant="ghost" size="sm" className="mb-4" data-testid="button-back">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>
        <h1 className="text-2xl font-bold tracking-tight" data-testid="text-page-title">
          Create New Campaign
        </h1>
        <p className="text-muted-foreground">
          Define your campaign parameters to generate audience segments and creative recommendations
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <div className="h-8 w-8 rounded-md bg-primary/10 flex items-center justify-center">
                  <Sparkles className="h-4 w-4 text-primary" />
                </div>
                Campaign Details
              </CardTitle>
              <CardDescription>
                Basic information about your campaign
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Campaign Name</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="e.g., Q1 Product Launch Campaign"
                        data-testid="input-campaign-name"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Describe the purpose and key objectives of this campaign..."
                        className="resize-none"
                        rows={3}
                        data-testid="input-description"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <div className="h-8 w-8 rounded-md bg-primary/10 flex items-center justify-center">
                  <Target className="h-4 w-4 text-primary" />
                </div>
                Campaign Goal
              </CardTitle>
              <CardDescription>
                What do you want to achieve with this campaign?
              </CardDescription>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="goal"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <div className="grid gap-3 sm:grid-cols-3">
                        {campaignGoals.map((goal) => {
                          const Icon = goalIcons[goal];
                          const isSelected = field.value === goal;
                          return (
                            <div
                              key={goal}
                              onClick={() => field.onChange(goal)}
                              className={`relative flex flex-col items-center p-4 rounded-md border-2 cursor-pointer transition-all hover-elevate ${
                                isSelected
                                  ? "border-primary bg-primary/5"
                                  : "border-border"
                              }`}
                              data-testid={`option-goal-${goal}`}
                            >
                              <Icon className={`h-6 w-6 mb-2 ${isSelected ? "text-primary" : "text-muted-foreground"}`} />
                              <span className="text-sm font-medium text-center">
                                {goalLabels[goal]}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <div className="h-8 w-8 rounded-md bg-primary/10 flex items-center justify-center">
                  <Package className="h-4 w-4 text-primary" />
                </div>
                Product & Tactic
              </CardTitle>
              <CardDescription>
                Select the product focus and marketing approach
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="product"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Product</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-product">
                          <SelectValue placeholder="Select a product" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {products.map((product) => (
                          <SelectItem key={product} value={product} data-testid={`option-product-${product}`}>
                            {productLabels[product]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="tactic"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tactic</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-tactic">
                          <SelectValue placeholder="Select a tactic" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {tactics.map((tactic) => (
                          <SelectItem key={tactic} value={tactic} data-testid={`option-tactic-${tactic}`}>
                            {tacticLabels[tactic]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <div className="h-8 w-8 rounded-md bg-primary/10 flex items-center justify-center">
                  <Radio className="h-4 w-4 text-primary" />
                </div>
                Channels
              </CardTitle>
              <CardDescription>
                Select the channels for this campaign
              </CardDescription>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="channels"
                render={() => (
                  <FormItem>
                    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                      {channels.map((channel) => {
                        const isChecked = selectedChannels.includes(channel);
                        return (
                          <div
                            key={channel}
                            className={`flex items-center space-x-3 p-3 rounded-md border-2 transition-all ${
                              isChecked ? "border-primary bg-primary/5" : "border-border"
                            }`}
                          >
                            <Checkbox
                              id={channel}
                              checked={isChecked}
                              onCheckedChange={(checked) =>
                                handleChannelToggle(channel, checked as boolean)
                              }
                              data-testid={`checkbox-channel-${channel}`}
                            />
                            <label
                              htmlFor={channel}
                              className="flex items-center gap-2 text-sm font-medium cursor-pointer flex-1"
                            >
                              {(() => {
                                const Icon = channelIcons[channel];
                                return <Icon className="h-4 w-4 text-muted-foreground" />;
                              })()}
                              {channelLabels[channel]}
                            </label>
                          </div>
                        );
                      })}
                    </div>
                    <FormDescription className="mt-3">
                      Select at least one channel for your campaign
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <div className="flex justify-end gap-3">
            <Link href="/">
              <Button variant="outline" type="button" data-testid="button-cancel">
                Cancel
              </Button>
            </Link>
            <Button
              type="submit"
              disabled={createCampaign.isPending}
              data-testid="button-create-campaign"
            >
              {createCampaign.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                <>
                  <Zap className="h-4 w-4 mr-2" />
                  Create Campaign
                </>
              )}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
