import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { PlusCircle, TrendingUp, Users, Mail, Target, ArrowRight, Clock, Activity } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import type { Campaign, CampaignStatus } from "@shared/schema";
import { goalLabels, productLabels, tacticLabels, statusLabels } from "@shared/schema";

function getStatusVariant(status: CampaignStatus): "default" | "secondary" | "destructive" | "outline" {
  switch (status) {
    case "active":
      return "default";
    case "draft":
      return "secondary";
    case "paused":
      return "outline";
    case "completed":
      return "secondary";
    default:
      return "secondary";
  }
}

function CampaignCard({ campaign }: { campaign: Campaign }) {
  return (
    <Link href={`/campaigns/${campaign.id}`} data-testid={`card-campaign-${campaign.id}`}>
      <Card className="hover-elevate cursor-pointer transition-all">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <CardTitle className="text-base truncate" data-testid={`text-campaign-name-${campaign.id}`}>
                {campaign.name}
              </CardTitle>
              <CardDescription className="mt-1 line-clamp-2">
                {campaign.description}
              </CardDescription>
            </div>
            <Badge variant={getStatusVariant(campaign.status)} data-testid={`badge-status-${campaign.id}`}>
              {statusLabels[campaign.status]}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2 mb-3">
            <Badge variant="outline" className="text-xs">
              {goalLabels[campaign.goal]}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {productLabels[campaign.product]}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {tacticLabels[campaign.tactic]}
            </Badge>
          </div>
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Users className="h-3.5 w-3.5" />
              <span data-testid={`text-audience-size-${campaign.id}`}>
                {campaign.targetAudienceSize.toLocaleString()} users
              </span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              <span>{new Date(campaign.createdAt).toLocaleDateString()}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

function StatCard({ 
  title, 
  value, 
  description, 
  icon: Icon, 
  trend 
}: { 
  title: string; 
  value: string; 
  description: string; 
  icon: typeof TrendingUp;
  trend?: string;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold" data-testid={`stat-${title.toLowerCase().replace(/\s+/g, '-')}`}>
          {value}
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          {description}
          {trend && (
            <span className="text-emerald-600 dark:text-emerald-400 ml-1">
              {trend}
            </span>
          )}
        </p>
      </CardContent>
    </Card>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <Skeleton className="h-4 w-24" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-16" />
              <Skeleton className="h-3 w-32 mt-2" />
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-5 w-40" />
              <Skeleton className="h-4 w-60 mt-1" />
            </CardHeader>
            <CardContent>
              <div className="flex gap-2 mb-3">
                <Skeleton className="h-5 w-20" />
                <Skeleton className="h-5 w-20" />
              </div>
              <Skeleton className="h-4 w-32" />
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { data: campaigns, isLoading } = useQuery<Campaign[]>({
    queryKey: ["/api/campaigns"],
  });

  const activeCampaigns = campaigns?.filter((c) => c.status === "active").length ?? 0;
  const totalAudience = campaigns?.reduce((sum, c) => sum + c.targetAudienceSize, 0) ?? 0;
  const draftCampaigns = campaigns?.filter((c) => c.status === "draft").length ?? 0;

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="mb-6">
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-72" />
        </div>
        <DashboardSkeleton />
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-dashboard-title">
            Campaign Dashboard
          </h1>
          <p className="text-muted-foreground">
            Manage your marketing campaigns and track performance
          </p>
        </div>
        <Link href="/campaigns/new">
          <Button data-testid="button-new-campaign">
            <PlusCircle className="h-4 w-4 mr-2" />
            New Campaign
          </Button>
        </Link>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
        <StatCard
          title="Active Campaigns"
          value={activeCampaigns.toString()}
          description="Currently running"
          icon={Activity}
          trend="+2 this week"
        />
        <StatCard
          title="Total Reach"
          value={totalAudience.toLocaleString()}
          description="Addressable audience"
          icon={Users}
        />
        <StatCard
          title="Draft Campaigns"
          value={draftCampaigns.toString()}
          description="Ready to launch"
          icon={Target}
        />
        <StatCard
          title="Avg. Open Rate"
          value="34.2%"
          description="Across all channels"
          icon={Mail}
          trend="+5.2%"
        />
      </div>

      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Recent Campaigns</h2>
        <Link href="/campaigns">
          <Button variant="ghost" size="sm" data-testid="button-view-all-campaigns">
            View all
            <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </Link>
      </div>

      {campaigns && campaigns.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {campaigns.slice(0, 6).map((campaign) => (
            <CampaignCard key={campaign.id} campaign={campaign} />
          ))}
        </div>
      ) : (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-muted p-3 mb-4">
              <Target className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="font-semibold mb-1">No campaigns yet</h3>
            <p className="text-muted-foreground text-sm text-center mb-4">
              Create your first campaign to start reaching your audience
            </p>
            <Link href="/campaigns/new">
              <Button data-testid="button-create-first-campaign">
                <PlusCircle className="h-4 w-4 mr-2" />
                Create Campaign
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
