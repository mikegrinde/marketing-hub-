import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams, Link, useLocation } from "wouter";
import {
  ArrowLeft,
  Users,
  Mail,
  MessageSquare,
  Smartphone,
  Megaphone,
  Target,
  FileText,
  Image,
  Play,
  Pause,
  CheckCircle2,
  Clock,
  TrendingUp,
  BarChart3,
  Loader2,
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type {
  Campaign,
  AudienceSegment,
  CreativeRecommendation,
  CampaignStatus,
} from "@shared/schema";
import {
  goalLabels,
  productLabels,
  tacticLabels,
  channelLabels,
  statusLabels,
} from "@shared/schema";

const channelIcons: Record<string, typeof Mail> = {
  email: Mail,
  sms: MessageSquare,
  mobile_push: Smartphone,
  paid: Megaphone,
};

function getStatusVariant(status: CampaignStatus): "default" | "secondary" | "destructive" | "outline" {
  switch (status) {
    case "active":
      return "default";
    case "draft":
      return "secondary";
    case "paused":
      return "outline";
    case "completed":
      return "secondary";
    default:
      return "secondary";
  }
}

function AudienceTab({ segment, isLoading }: { segment?: AudienceSegment; isLoading: boolean }) {
  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (!segment) {
    return (
      <Card className="border-dashed">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Users className="h-8 w-8 text-muted-foreground mb-4" />
          <p className="text-muted-foreground">No audience data available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Audience
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-total-audience">
              {segment.totalSize.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Matched customers</p>
          </CardContent>
        </Card>

        {Object.entries(segment.channelReach).map(([channel, count]) => {
          const Icon = channelIcons[channel as keyof typeof channelIcons];
          return (
            <Card key={channel}>
              <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {channelLabels[channel as keyof typeof channelLabels]}
                </CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{count.toLocaleString()}</div>
                <Progress
                  value={(count / segment.totalSize) * 100}
                  className="mt-2 h-1.5"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  {Math.round((count / segment.totalSize) * 100)}% reachable
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Audience Breakdown</CardTitle>
          <CardDescription>
            Segment characteristics based on CDP data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <p className="text-sm font-medium">By Company Size</p>
                <div className="space-y-1">
                  {["Enterprise", "Large", "Medium", "Small"].map((size, i) => (
                    <div key={size} className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">{size}</span>
                      <span className="font-medium">{Math.round(segment.totalSize * [0.15, 0.25, 0.35, 0.25][i])}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium">By Churn Risk</p>
                <div className="space-y-1">
                  {[
                    { label: "Low Risk", color: "bg-emerald-500", pct: 0.6 },
                    { label: "Medium Risk", color: "bg-amber-500", pct: 0.3 },
                    { label: "High Risk", color: "bg-red-500", pct: 0.1 },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center gap-2 text-sm">
                      <div className={`h-2 w-2 rounded-full ${item.color}`} />
                      <span className="text-muted-foreground flex-1">{item.label}</span>
                      <span className="font-medium">{Math.round(segment.totalSize * item.pct)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium">By CRM Stage</p>
                <div className="space-y-1">
                  {[
                    { label: "Active", pct: 0.45 },
                    { label: "Trial", pct: 0.2 },
                    { label: "At Risk", pct: 0.15 },
                    { label: "Prospect", pct: 0.2 },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">{item.label}</span>
                      <span className="font-medium">{Math.round(segment.totalSize * item.pct)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Sample Audience</CardTitle>
          <CardDescription>
            Preview of matched customers from your CDP
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[200px]">
            <div className="space-y-2">
              {segment.matchedCustomers.slice(0, 10).map((customer) => (
                <div
                  key={customer.id}
                  className="flex items-center justify-between p-3 rounded-md bg-muted/50"
                  data-testid={`customer-row-${customer.id}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-xs font-medium text-primary">
                        {customer.accountName.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">{customer.accountName}</p>
                      <p className="text-xs text-muted-foreground">{customer.industry}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <div className="text-right">
                      <p className="text-muted-foreground text-xs">Adoption</p>
                      <p className="font-medium">{customer.productAdoption.productA}%</p>
                    </div>
                    <Badge
                      variant={
                        customer.churnRisk === "low"
                          ? "secondary"
                          : customer.churnRisk === "medium"
                          ? "outline"
                          : "destructive"
                      }
                      className="text-xs"
                    >
                      {customer.churnRisk} risk
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

function CreativeTab({ creative, isLoading }: { creative?: CreativeRecommendation; isLoading: boolean }) {
  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (!creative) {
    return (
      <Card className="border-dashed">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <FileText className="h-8 w-8 text-muted-foreground mb-4" />
          <p className="text-muted-foreground">No creative recommendations available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Recommended Subject Lines
          </CardTitle>
          <CardDescription>
            AI-generated subject lines based on campaign parameters
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {creative.suggestedSubjectLines.map((subject, idx) => (
              <div
                key={idx}
                className="flex items-center gap-3 p-3 rounded-md bg-muted/50"
                data-testid={`subject-line-${idx}`}
              >
                <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-xs font-medium text-primary">{idx + 1}</span>
                </div>
                <p className="text-sm">{subject}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Recommended Timing
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground" data-testid="text-recommended-timing">
            {creative.recommendedTiming}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Narrative Templates
          </CardTitle>
          <CardDescription>
            Pre-approved messaging templates for your campaign
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {creative.narratives.map((narrative) => (
              <div
                key={narrative.id}
                className="p-4 rounded-md border"
                data-testid={`narrative-${narrative.id}`}
              >
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div>
                    <h4 className="font-semibold">{narrative.title}</h4>
                    <Badge variant="secondary" className="mt-1 text-xs">
                      {narrative.tone}
                    </Badge>
                  </div>
                </div>
                <div className="space-y-2 text-sm">
                  <div>
                    <p className="text-muted-foreground text-xs uppercase tracking-wide mb-1">Headline</p>
                    <p className="font-medium">{narrative.headline}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-xs uppercase tracking-wide mb-1">Subheadline</p>
                    <p>{narrative.subheadline}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-xs uppercase tracking-wide mb-1">Body</p>
                    <p className="text-muted-foreground">{narrative.bodyContent}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-xs uppercase tracking-wide mb-1">CTA</p>
                    <Badge variant="default">{narrative.callToAction}</Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Image className="h-5 w-5" />
            Creative Assets
          </CardTitle>
          <CardDescription>
            Available assets from your creative library
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2">
            {creative.assets.map((asset) => (
              <div
                key={asset.id}
                className="flex items-center gap-3 p-3 rounded-md border"
                data-testid={`asset-${asset.id}`}
              >
                <div className="h-12 w-12 rounded-md bg-muted flex items-center justify-center">
                  {asset.type === "image" ? (
                    <Image className="h-5 w-5 text-muted-foreground" />
                  ) : asset.type === "video" ? (
                    <Play className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <FileText className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{asset.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {asset.type.charAt(0).toUpperCase() + asset.type.slice(1)} • {channelLabels[asset.channel]}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function CampaignDetailSkeleton() {
  return (
    <div className="p-6">
      <Skeleton className="h-8 w-32 mb-4" />
      <div className="mb-6">
        <Skeleton className="h-8 w-64 mb-2" />
        <Skeleton className="h-4 w-96" />
      </div>
      <div className="flex gap-2 mb-6">
        <Skeleton className="h-6 w-20" />
        <Skeleton className="h-6 w-20" />
        <Skeleton className="h-6 w-20" />
      </div>
      <Skeleton className="h-96 w-full" />
    </div>
  );
}

export default function CampaignDetail() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: campaign, isLoading: campaignLoading } = useQuery<Campaign>({
    queryKey: ["/api/campaigns", id],
  });

  const { data: audience, isLoading: audienceLoading } = useQuery<AudienceSegment>({
    queryKey: ["/api/campaigns", id, "audience"],
    enabled: !!campaign,
  });

  const { data: creative, isLoading: creativeLoading } = useQuery<CreativeRecommendation>({
    queryKey: ["/api/campaigns", id, "creative"],
    enabled: !!campaign,
  });

  const updateStatus = useMutation({
    mutationFn: async (status: CampaignStatus) => {
      const response = await apiRequest("PATCH", `/api/campaigns/${id}`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns", id] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({
        title: "Status updated",
        description: "Campaign status has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update campaign status.",
        variant: "destructive",
      });
    },
  });

  if (campaignLoading) {
    return <CampaignDetailSkeleton />;
  }

  if (!campaign) {
    return (
      <div className="p-6">
        <Link href="/">
          <Button variant="ghost" size="sm" className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Target className="h-8 w-8 text-muted-foreground mb-4" />
            <h3 className="font-semibold mb-1">Campaign not found</h3>
            <p className="text-muted-foreground text-sm">
              This campaign may have been deleted or doesn't exist.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6">
      <Link href="/">
        <Button variant="ghost" size="sm" className="mb-4" data-testid="button-back">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
      </Link>

      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-2xl font-bold tracking-tight" data-testid="text-campaign-name">
              {campaign.name}
            </h1>
            <Badge variant={getStatusVariant(campaign.status)} data-testid="badge-campaign-status">
              {statusLabels[campaign.status]}
            </Badge>
          </div>
          <p className="text-muted-foreground max-w-2xl" data-testid="text-campaign-description">
            {campaign.description}
          </p>
        </div>

        <div className="flex gap-2 flex-wrap">
          {campaign.status === "draft" && (
            <Button
              onClick={() => updateStatus.mutate("active")}
              disabled={updateStatus.isPending}
              data-testid="button-activate"
            >
              {updateStatus.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Play className="h-4 w-4 mr-2" />
              )}
              Activate
            </Button>
          )}
          {campaign.status === "active" && (
            <Button
              variant="outline"
              onClick={() => updateStatus.mutate("paused")}
              disabled={updateStatus.isPending}
              data-testid="button-pause"
            >
              {updateStatus.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Pause className="h-4 w-4 mr-2" />
              )}
              Pause
            </Button>
          )}
          {campaign.status === "paused" && (
            <>
              <Button
                onClick={() => updateStatus.mutate("active")}
                disabled={updateStatus.isPending}
                data-testid="button-resume"
              >
                {updateStatus.isPending ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Play className="h-4 w-4 mr-2" />
                )}
                Resume
              </Button>
              <Button
                variant="secondary"
                onClick={() => updateStatus.mutate("completed")}
                disabled={updateStatus.isPending}
                data-testid="button-complete"
              >
                <CheckCircle2 className="h-4 w-4 mr-2" />
                Complete
              </Button>
            </>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        <Badge variant="outline">{goalLabels[campaign.goal]}</Badge>
        <Badge variant="outline">{productLabels[campaign.product]}</Badge>
        <Badge variant="outline">{tacticLabels[campaign.tactic]}</Badge>
        {campaign.channels.map((channel) => (
          <Badge key={channel} variant="secondary">
            {channelLabels[channel]}
          </Badge>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-3 mb-6">
        <Card>
          <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Target Audience
            </CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-target-audience">
              {campaign.targetAudienceSize.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Matched users</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Est. Open Rate
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">32.5%</div>
            <p className="text-xs text-muted-foreground mt-1">Based on historical data</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Est. Conversion
            </CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.8%</div>
            <p className="text-xs text-muted-foreground mt-1">Predicted outcome</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="audience" className="space-y-4">
        <TabsList>
          <TabsTrigger value="audience" data-testid="tab-audience">
            <Users className="h-4 w-4 mr-2" />
            Audience
          </TabsTrigger>
          <TabsTrigger value="creative" data-testid="tab-creative">
            <FileText className="h-4 w-4 mr-2" />
            Creative
          </TabsTrigger>
        </TabsList>
        <TabsContent value="audience">
          <AudienceTab segment={audience} isLoading={audienceLoading} />
        </TabsContent>
        <TabsContent value="creative">
          <CreativeTab creative={creative} isLoading={creativeLoading} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
