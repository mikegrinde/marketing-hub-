import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCampaignSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Get all campaigns
  app.get("/api/campaigns", async (req, res) => {
    try {
      const campaigns = await storage.getAllCampaigns();
      res.json(campaigns);
    } catch (error) {
      console.error("Error fetching campaigns:", error);
      res.status(500).json({ error: "Failed to fetch campaigns" });
    }
  });

  // Get single campaign
  app.get("/api/campaigns/:id", async (req, res) => {
    try {
      const campaign = await storage.getCampaign(req.params.id);
      if (!campaign) {
        return res.status(404).json({ error: "Campaign not found" });
      }
      res.json(campaign);
    } catch (error) {
      console.error("Error fetching campaign:", error);
      res.status(500).json({ error: "Failed to fetch campaign" });
    }
  });

  // Create campaign
  app.post("/api/campaigns", async (req, res) => {
    try {
      const parsed = insertCampaignSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ 
          error: "Invalid campaign data", 
          details: parsed.error.errors 
        });
      }
      
      const campaign = await storage.createCampaign(parsed.data);
      res.status(201).json(campaign);
    } catch (error) {
      console.error("Error creating campaign:", error);
      res.status(500).json({ error: "Failed to create campaign" });
    }
  });

  // Update campaign
  app.patch("/api/campaigns/:id", async (req, res) => {
    try {
      const updateSchema = z.object({
        name: z.string().min(1).optional(),
        description: z.string().min(1).optional(),
        status: z.enum(["draft", "active", "paused", "completed"]).optional(),
      });

      const parsed = updateSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ 
          error: "Invalid update data", 
          details: parsed.error.errors 
        });
      }

      const campaign = await storage.updateCampaign(req.params.id, parsed.data);
      if (!campaign) {
        return res.status(404).json({ error: "Campaign not found" });
      }
      
      res.json(campaign);
    } catch (error) {
      console.error("Error updating campaign:", error);
      res.status(500).json({ error: "Failed to update campaign" });
    }
  });

  // Delete campaign
  app.delete("/api/campaigns/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteCampaign(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Campaign not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting campaign:", error);
      res.status(500).json({ error: "Failed to delete campaign" });
    }
  });

  // Get audience segment for a campaign
  app.get("/api/campaigns/:id/audience", async (req, res) => {
    try {
      const segment = await storage.getAudienceSegment(req.params.id);
      if (!segment) {
        return res.status(404).json({ error: "Campaign not found" });
      }
      res.json(segment);
    } catch (error) {
      console.error("Error fetching audience segment:", error);
      res.status(500).json({ error: "Failed to fetch audience segment" });
    }
  });

  // Get creative recommendations for a campaign
  app.get("/api/campaigns/:id/creative", async (req, res) => {
    try {
      const creative = await storage.getCreativeRecommendation(req.params.id);
      if (!creative) {
        return res.status(404).json({ error: "Campaign not found" });
      }
      res.json(creative);
    } catch (error) {
      console.error("Error fetching creative recommendations:", error);
      res.status(500).json({ error: "Failed to fetch creative recommendations" });
    }
  });

  return httpServer;
}
