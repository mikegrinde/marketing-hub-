import {
  type User,
  type InsertUser,
  type Campaign,
  type InsertCampaign,
  type CDPCustomer,
  type AudienceSegment,
  type CreativeRecommendation,
  type Narrative,
  type CreativeAsset,
  type CampaignGoal,
  type Product,
  type Tactic,
  type Channel,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Campaigns
  getAllCampaigns(): Promise<Campaign[]>;
  getCampaign(id: string): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaign(id: string, updates: Partial<Campaign>): Promise<Campaign | undefined>;
  deleteCampaign(id: string): Promise<boolean>;
  
  // CDP Data
  getAudienceSegment(campaignId: string): Promise<AudienceSegment | undefined>;
  
  // Creative
  getCreativeRecommendation(campaignId: string): Promise<CreativeRecommendation | undefined>;
}

// Generate mock CDP customers
function generateMockCDPCustomers(count: number): CDPCustomer[] {
  const industries = ["Technology", "Healthcare", "Finance", "Retail", "Manufacturing", "Education", "Media", "Consulting"];
  const companySizes: CDPCustomer["companySize"][] = ["small", "medium", "large", "enterprise"];
  const crmStages: CDPCustomer["crmStage"][] = ["prospect", "trial", "active", "at_risk", "churned"];
  const churnRisks: CDPCustomer["churnRisk"][] = ["low", "medium", "high"];
  
  const companyNames = [
    "Acme Corp", "TechVision Inc", "Global Solutions", "Innovate Labs", "DataDriven Co",
    "CloudScale Systems", "Nexus Technologies", "Velocity Partners", "Summit Enterprises", "Quantum Dynamics",
    "Alpha Industries", "Beta Solutions", "Gamma Tech", "Delta Systems", "Epsilon Analytics",
    "Zeta Digital", "Theta Innovations", "Iota Consulting", "Kappa Networks", "Lambda Software"
  ];

  return Array.from({ length: count }, (_, i) => ({
    id: randomUUID(),
    accountName: companyNames[i % companyNames.length] + (i >= companyNames.length ? ` ${Math.floor(i / companyNames.length) + 1}` : ""),
    industry: industries[Math.floor(Math.random() * industries.length)],
    companySize: companySizes[Math.floor(Math.random() * companySizes.length)],
    productAdoption: {
      productA: Math.floor(Math.random() * 100),
      productB: Math.floor(Math.random() * 100),
      productC: Math.floor(Math.random() * 100),
    },
    lastActivity: new Date(Date.now() - Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000).toISOString(),
    onboardingComplete: Math.random() > 0.3,
    churnRisk: churnRisks[Math.floor(Math.random() * churnRisks.length)],
    headroom: Math.floor(Math.random() * 100),
    crmStage: crmStages[Math.floor(Math.random() * crmStages.length)],
    marketingOptIn: {
      email: Math.random() > 0.2,
      sms: Math.random() > 0.5,
      mobile_push: Math.random() > 0.4,
      paid: Math.random() > 0.3,
    },
  }));
}

// Generate narratives based on campaign parameters
function generateNarratives(goal: CampaignGoal, product: Product, tactic: Tactic): Narrative[] {
  const narrativesByGoal: Record<CampaignGoal, Narrative[]> = {
    onboarding: [
      {
        id: randomUUID(),
        title: "Welcome Journey",
        headline: "Welcome to Your Success Journey",
        subheadline: "Get started with the tools that will transform your workflow",
        bodyContent: "We're excited to have you on board! Our step-by-step guide will help you unlock the full potential of your new platform. Let's make your first week count.",
        callToAction: "Start Your Journey",
        goal: "onboarding",
        product,
        tactic,
        tone: "friendly",
      },
      {
        id: randomUUID(),
        title: "Quick Start Guide",
        headline: "5 Minutes to Mastery",
        subheadline: "The fastest path from signup to success",
        bodyContent: "Don't let complexity slow you down. Our quick start guide covers everything you need to know in just 5 minutes. You'll be up and running before you know it.",
        callToAction: "Get Started Now",
        goal: "onboarding",
        product,
        tactic,
        tone: "professional",
      },
    ],
    product_adoption: [
      {
        id: randomUUID(),
        title: "Feature Spotlight",
        headline: "Unlock Hidden Potential",
        subheadline: "Discover features that 90% of users miss",
        bodyContent: "You're already seeing results, but there's so much more to explore. Learn about the advanced features that our most successful customers use every day.",
        callToAction: "Explore Features",
        goal: "product_adoption",
        product,
        tactic,
        tone: "educational",
      },
      {
        id: randomUUID(),
        title: "Power User Tips",
        headline: "Level Up Your Productivity",
        subheadline: "Pro tips from our most successful users",
        bodyContent: "Our power users have discovered shortcuts and workflows that save hours each week. Now it's your turn to unlock these productivity secrets.",
        callToAction: "Learn Pro Tips",
        goal: "product_adoption",
        product,
        tactic,
        tone: "friendly",
      },
    ],
    new_product_awareness: [
      {
        id: randomUUID(),
        title: "Product Launch",
        headline: "Introducing Something Revolutionary",
        subheadline: "The solution you've been waiting for",
        bodyContent: "We've listened to your feedback and built something extraordinary. Our latest product is designed to solve the challenges you face every day.",
        callToAction: "See What's New",
        goal: "new_product_awareness",
        product,
        tactic,
        tone: "professional",
      },
      {
        id: randomUUID(),
        title: "Exclusive Preview",
        headline: "Be Among the First",
        subheadline: "Early access to our newest innovation",
        bodyContent: "As a valued customer, you're getting an exclusive first look at our latest offering. Don't miss this opportunity to stay ahead of the curve.",
        callToAction: "Get Early Access",
        goal: "new_product_awareness",
        product,
        tactic,
        tone: "urgent",
      },
    ],
  };

  return narrativesByGoal[goal];
}

// Generate creative assets based on campaign parameters
function generateCreativeAssets(goal: CampaignGoal, product: Product, tactic: Tactic, channels: Channel[]): CreativeAsset[] {
  const assets: CreativeAsset[] = [];
  
  channels.forEach((channel) => {
    assets.push(
      {
        id: randomUUID(),
        name: `${goal.replace("_", " ")} Hero Banner`,
        type: "image",
        category: goal,
        product,
        tactic,
        channel,
        content: "High-impact visual showcasing product benefits",
      },
      {
        id: randomUUID(),
        name: `${channel} Copy Template`,
        type: "copy",
        category: goal,
        product,
        tactic,
        channel,
        content: "Optimized messaging template for this channel",
      }
    );
  });

  if (channels.includes("email")) {
    assets.push({
      id: randomUUID(),
      name: "Email HTML Template",
      type: "template",
      category: goal,
      product,
      tactic,
      channel: "email",
      content: "Responsive email template with dynamic content blocks",
    });
  }

  return assets;
}

// Generate subject lines based on goal and tactic
function generateSubjectLines(goal: CampaignGoal, tactic: Tactic): string[] {
  const subjectsByGoal: Record<CampaignGoal, string[]> = {
    onboarding: [
      "Welcome aboard! Here's your quick start guide",
      "Your first step to success starts here",
      "Ready to get started? We'll show you how",
      "Your personalized onboarding checklist is ready",
    ],
    product_adoption: [
      "You're missing out on these powerful features",
      "Unlock your full potential with these tips",
      "See what top performers are doing differently",
      "Your weekly product insights are here",
    ],
    new_product_awareness: [
      "Introducing something you'll love",
      "Big news: A new solution for your challenges",
      "Exclusive preview: See it before anyone else",
      "The feature you've been asking for is here",
    ],
  };

  return subjectsByGoal[goal];
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private campaigns: Map<string, Campaign>;
  private cdpCustomers: CDPCustomer[];

  constructor() {
    this.users = new Map();
    this.campaigns = new Map();
    this.cdpCustomers = generateMockCDPCustomers(100);
    
    // Add some sample campaigns
    this.initializeSampleCampaigns();
  }

  private initializeSampleCampaigns() {
    const sampleCampaigns: InsertCampaign[] = [
      {
        name: "Q1 New User Onboarding",
        description: "Comprehensive onboarding campaign for new users signed up in January",
        goal: "onboarding",
        product: "product_a",
        tactic: "onboarding_checklist",
        channels: ["email", "mobile_push"],
      },
      {
        name: "Product B Feature Adoption Drive",
        description: "Increase adoption of advanced features among existing Product B users",
        goal: "product_adoption",
        product: "product_b",
        tactic: "promotion",
        channels: ["email", "sms"],
      },
      {
        name: "Product C Launch Campaign",
        description: "Awareness campaign for the upcoming Product C release",
        goal: "new_product_awareness",
        product: "product_c",
        tactic: "promotion",
        channels: ["email", "paid"],
      },
    ];

    sampleCampaigns.forEach((campaign, index) => {
      const id = randomUUID();
      const now = new Date();
      now.setDate(now.getDate() - (index * 3));
      
      this.campaigns.set(id, {
        id,
        ...campaign,
        status: index === 0 ? "active" : index === 1 ? "draft" : "completed",
        targetAudienceSize: Math.floor(Math.random() * 5000) + 1000,
        createdAt: now.toISOString(),
        updatedAt: now.toISOString(),
      });
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Campaign methods
  async getAllCampaigns(): Promise<Campaign[]> {
    return Array.from(this.campaigns.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getCampaign(id: string): Promise<Campaign | undefined> {
    return this.campaigns.get(id);
  }

  async createCampaign(insertCampaign: InsertCampaign): Promise<Campaign> {
    const id = randomUUID();
    const now = new Date().toISOString();
    
    // Calculate target audience based on channels
    const eligibleCustomers = this.cdpCustomers.filter((customer) =>
      insertCampaign.channels.some((channel) => customer.marketingOptIn[channel])
    );
    
    const campaign: Campaign = {
      id,
      ...insertCampaign,
      status: "draft",
      targetAudienceSize: eligibleCustomers.length,
      createdAt: now,
      updatedAt: now,
    };
    
    this.campaigns.set(id, campaign);
    return campaign;
  }

  async updateCampaign(id: string, updates: Partial<Campaign>): Promise<Campaign | undefined> {
    const campaign = this.campaigns.get(id);
    if (!campaign) return undefined;
    
    const updatedCampaign: Campaign = {
      ...campaign,
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    
    this.campaigns.set(id, updatedCampaign);
    return updatedCampaign;
  }

  async deleteCampaign(id: string): Promise<boolean> {
    return this.campaigns.delete(id);
  }

  // CDP / Audience methods
  async getAudienceSegment(campaignId: string): Promise<AudienceSegment | undefined> {
    const campaign = this.campaigns.get(campaignId);
    if (!campaign) return undefined;

    // Filter customers based on campaign criteria
    let matchedCustomers = this.cdpCustomers.filter((customer) => {
      // Must have opted in to at least one selected channel
      const hasChannelOptIn = campaign.channels.some(
        (channel) => customer.marketingOptIn[channel]
      );
      if (!hasChannelOptIn) return false;

      // Apply goal-based filtering
      switch (campaign.goal) {
        case "onboarding":
          return !customer.onboardingComplete;
        case "product_adoption":
          // Target users with low adoption of the selected product
          const productKey = campaign.product.replace("product_", "product") as keyof typeof customer.productAdoption;
          return customer.productAdoption[productKey] < 50;
        case "new_product_awareness":
          return customer.crmStage === "active" || customer.crmStage === "trial";
        default:
          return true;
      }
    });

    // Apply tactic-based filtering
    switch (campaign.tactic) {
      case "churn_prevention":
        matchedCustomers = matchedCustomers.filter(
          (c) => c.churnRisk === "medium" || c.churnRisk === "high"
        );
        break;
      case "promotion":
        matchedCustomers = matchedCustomers.filter((c) => c.headroom > 30);
        break;
    }

    // Calculate channel reach
    const channelReach = {
      email: matchedCustomers.filter((c) => c.marketingOptIn.email).length,
      sms: matchedCustomers.filter((c) => c.marketingOptIn.sms).length,
      mobile_push: matchedCustomers.filter((c) => c.marketingOptIn.mobile_push).length,
      paid: matchedCustomers.filter((c) => c.marketingOptIn.paid).length,
    };

    return {
      totalSize: matchedCustomers.length,
      matchedCustomers: matchedCustomers.slice(0, 20), // Return sample
      segmentCriteria: {
        goal: campaign.goal,
        product: campaign.product,
        tactic: campaign.tactic,
        channels: campaign.channels,
      },
      channelReach,
    };
  }

  // Creative methods
  async getCreativeRecommendation(campaignId: string): Promise<CreativeRecommendation | undefined> {
    const campaign = this.campaigns.get(campaignId);
    if (!campaign) return undefined;

    const narratives = generateNarratives(campaign.goal, campaign.product, campaign.tactic);
    const assets = generateCreativeAssets(campaign.goal, campaign.product, campaign.tactic, campaign.channels);
    const subjectLines = generateSubjectLines(campaign.goal, campaign.tactic);

    // Generate recommended timing based on goal
    const timingRecommendations: Record<CampaignGoal, string> = {
      onboarding: "Best sent within 24 hours of user signup. Optimal send times: Tuesday-Thursday, 10am-2pm local time.",
      product_adoption: "Weekly touchpoints work best. Consider Tuesday or Wednesday mornings for highest engagement.",
      new_product_awareness: "Launch announcements perform best mid-week. Follow up 3-5 days later for non-openers.",
    };

    return {
      narratives,
      assets,
      suggestedSubjectLines: subjectLines,
      recommendedTiming: timingRecommendations[campaign.goal],
    };
  }
}

export const storage = new MemStorage();
