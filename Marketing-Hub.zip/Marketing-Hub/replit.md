# Campaign Manager - Marketing Hub

A centralized campaign management platform for Product and Lifecycle marketers to plan and initiate marketing activations.

## Overview

This application provides marketers with tools to create campaigns, segment audiences based on CDP data, and receive creative recommendations for their marketing initiatives.

## Features

- **Campaign Dashboard**: View all campaigns with status, audience size, and key metrics
- **Campaign Creation**: Easy-to-use form for defining campaign parameters (goals, products, tactics, channels)
- **Audience Segmentation**: Automatic audience matching based on CDP customer data
- **Creative Recommendations**: AI-generated narratives, subject lines, and asset suggestions

## Campaign Configuration Options

### Goals
- Onboarding
- Product Adoption
- New Product Awareness

### Products
- Product A
- Product B
- Product C

### Tactics
- Onboarding Checklist
- Churn Prevention
- Promotion

### Channels
- Email
- SMS
- Mobile Push
- Paid Ads

## Architecture

### Frontend (client/)
- React with TypeScript
- Wouter for routing
- TanStack Query for data fetching
- Shadcn UI components
- Tailwind CSS for styling

### Backend (server/)
- Express.js
- In-memory storage with mock CDP data
- RESTful API endpoints

### Key Files
- `shared/schema.ts` - Data models and TypeScript interfaces
- `server/storage.ts` - Storage layer with mock CDP customer generation
- `server/routes.ts` - API endpoints
- `client/src/pages/` - React page components

## API Endpoints

- `GET /api/campaigns` - List all campaigns
- `POST /api/campaigns` - Create new campaign
- `GET /api/campaigns/:id` - Get campaign details
- `PATCH /api/campaigns/:id` - Update campaign status
- `GET /api/campaigns/:id/audience` - Get audience segmentation
- `GET /api/campaigns/:id/creative` - Get creative recommendations

## Development

The application runs with `npm run dev` which starts both the Express backend and Vite frontend on port 5000.

## Design System

Uses a professional blue-focused color scheme suitable for marketing/B2B applications with full dark mode support.
